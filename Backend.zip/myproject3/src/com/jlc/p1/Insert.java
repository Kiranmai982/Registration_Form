package com.jlc.p1;

import java.sql.Connection;
import java.sql.Statement;
import com.JDBCUtil.JDBCUtil;

public class Insert {
	public static void main(String[] args) {
		Connection con=null;
		Statement st =null;
		try {
		
		con = JDBCUtil.getConnection();
		String SQL = "INSERT INTO Registration (Name, Email, DateOfBirth, PhoneNumber, Address) \r\n"
				+ "VALUES \r\n"
				+ "('John Doe', 'john.doe@example.com', '1995-07-15', '1234567890', '123 Main St, Bengaluru, Karnataka');\r\n"
				+ "";
		st = con.createStatement();
		int x = st.executeUpdate(SQL);
		System.out.println(x);
		}catch(Exception e3) {
			System.out.println(e3);
		}finally {
			JDBCUtil.cleanup(st, con);
		}
	}


}

package com.jlc.p1;

import java.sql.Connection;
import java.sql.Statement;
import com.JDBCUtil.JDBCUtil;

public class Update {
    public static void main(String[] args) {
        Connection con = null;
        Statement st = null;
        try {
            con = JDBCUtil.getConnection();
            String SQL = "UPDATE Registration " +
                         "SET Name = 'Jane Doe', Email = 'jane.doe@example.com', " +
                         "PhoneNumber = '9876543210', Address = '456 Park St, Bengaluru, Karnataka' " +
                         "WHERE ID = 1;";
            st = con.createStatement();
            int x = st.executeUpdate(SQL);
            System.out.println(x + " record(s) updated.");
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            JDBCUtil.cleanup(st, con);
        }
    }
}

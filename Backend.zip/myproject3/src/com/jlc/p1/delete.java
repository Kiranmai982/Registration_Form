package com.jlc.p1;

import java.sql.Connection;
import java.sql.Statement;
import com.JDBCUtil.JDBCUtil;

public class delete {
    public static void main(String[] args) {
        Connection con = null;
        Statement st = null;
        try {
            con = JDBCUtil.getConnection();
            String SQL = "DELETE FROM Registration WHERE ID = 1;";
            st = con.createStatement();
            int x = st.executeUpdate(SQL);
            System.out.println(x + " record(s) deleted.");
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            JDBCUtil.cleanup(st, con);
        }
    }
}


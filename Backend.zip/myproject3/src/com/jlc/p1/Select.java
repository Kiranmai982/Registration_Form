package com.jlc.p1;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import com.JDBCUtil.JDBCUtil;

public class Select {
    public static void main(String[] args) {
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        try {
            con = JDBCUtil.getConnection();
            String SQL = "SELECT * FROM Registration;";
            st = con.createStatement();
            rs = st.executeQuery(SQL);

            while (rs.next()) {
                int id = rs.getInt("ID");
                String name = rs.getString("Name");
                String email = rs.getString("Email");
                String dateOfBirth = rs.getString("DateOfBirth");
                String phoneNumber = rs.getString("PhoneNumber");
                String address = rs.getString("Address");
                String registrationDate = rs.getString("RegistrationDate");

                System.out.println("ID: " + id);
                System.out.println("Name: " + name);
                System.out.println("Email: " + email);
                System.out.println("Date of Birth: " + dateOfBirth);
                System.out.println("Phone Number: " + phoneNumber);
                System.out.println("Address: " + address);
                System.out.println("Registration Date: " + registrationDate);
                System.out.println("-------------------------");
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            JDBCUtil.cleanup(rs, st, con);
        }
    }
}

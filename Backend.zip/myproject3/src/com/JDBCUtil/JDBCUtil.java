package com.JDBCUtil;


import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

public class JDBCUtil {

	
		public static Connection getConnection() {
		Connection con = null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/myjdbcdb","root","Kiran@2003");
			
		}catch(Exception ex) {
			System.out.println(ex);
		
		}
		return con;
		}

		public static void cleanup(ResultSet r, Statement st, Connection con) {
			try {
				if(r !=null) {
					r.close();
				}
				if(st != null) {
					st.close();
				}
				if(con != null) {
					con.close();
				}
			}catch(Exception e) {
				System.out.println(e);
			}
		}
		public static void cleanup(Statement st, Connection con) {
			try {
				if(st != null) {
					st.close();
				}
				if(con != null) {
					con.close();
				}
			}catch(Exception e1) {
				System.out.println(e1);
			}
		}
		
			
}
	


